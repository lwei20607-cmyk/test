# Real-device test plan — v4.3

Use the SAME iPhone for each H5/App pair.

## A. Current H5 legacy experiment
1. Open the current Shopify H5 on the iPhone.
2. Obtain the output of the existing `getHWFingerprint()`.
3. Open the IPA and paste that value into `Paste H5 legacy HW result`.
4. Record whether Algorithm A shows MATCH or MISMATCH.
5. Save the App Algorithm A canonical string. A mismatch is allowed/expected because Safari WebGL/browser values may differ from native Metal/native values.

## B. Cross-surface v2
1. Add/run the included `H5_FINGERPRINT_V2.js` on the same H5 page.
2. Record `AttributionFingerprintV2.canonicalString()` and `AttributionFingerprintV2.fingerprint()`.
3. Open the IPA and compare the App Algorithm B canonical string and HW result.
4. They should match if both sides expose/normalize the common fields identically.

## C. Worker hardware-fingerprint match tests
For each algorithm separately:
1. Create an H5 attribution/click record using that H5 fingerprint.
2. In IPA select the corresponding algorithm.
3. Select `Fingerprint only` so short_code is omitted.
4. Send event.
5. Verify Worker/D1 shows `matched=true` and `match_method=hw_fingerprint`.

Then test Short + Fingerprint; Worker should prefer short_code.

## D. Worker network fallback test — IMPORTANT
The current Worker hashes **IP + UA** for network fingerprint. H5 Safari UA differs from native App UA.
1. On the SAME H5 page/network used to create the click, copy `navigator.userAgent` exactly.
2. In the IPA paste it into `H5 browser User-Agent (for network fallback)`.
3. Keep the phone on the same public network/IP as the H5 click where practical.
4. Press `Test network fallback only`.
5. The app omits short_code and hw_fingerprint, and sends the pasted H5 UA in `user_agent`.
6. Verify `matched=true` and `match_method=network_fingerprint`.

If the H5 UA field is blank, the Worker falls back to the native app request UA, so an H5-created network fingerprint will normally not match.

## E. Event buttons
- `Set ...` only changes `event_type`.
- `Send View now`, `Send Register now`, and `Send Purchase now` immediately POST `/r/app/event`.
- `Send CURRENT event` sends the text-field event using the selected mode.
- The Worker's active strategy must contain the corresponding trigger/mapping before you expect `triggered=true` or TikTok delivery. The app can still POST an event even when Worker strategy config does not currently trigger it.

## F. Regression buttons
- short_code + selected fingerprint: explicit short+fingerprint mode.
- selected fingerprint fallback only: explicit fingerprint-only mode.
- network fallback only: explicit network-only mode.
- both algorithms: A then B, fingerprint-only.
- core attribution sequence: health, short+fingerprint, fingerprint-only, network-only.

## G. Multi-device matrix
Repeat on iPhone 6s (iOS 15.8), iPhone 11, iPhone 13, and other available iPhones running iOS 15+. Record model, iOS version, H5/App canonical strings, both HW values, event_id, HTTP response, D1 match_method, and TikTok Test Events result where applicable.
