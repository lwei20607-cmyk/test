# Fingerprint specification — v4.3

## Algorithm A: LEGACY_H5_LAYOUT_NATIVE_APPROX_V1
Keeps the exact legacy H5 field order and JS32 hash, but substitutes closest native iOS analogues for browser-only fields. It is an experiment, not a guaranteed cross-surface identifier.

Legacy H5 fields:
`WebGL renderer | WebGL vendor | hardwareConcurrency | screen WxH | DPR | timezone`

Native approximation:
`Metal device name | Apple | processorCount | UIScreen points WxH | UIScreen.scale | timezone`

Because WebGL/Metal and browser/native CPU exposure are not guaranteed identical, a mismatch does not indicate a hash bug.

## Algorithm B: CROSS_SURFACE_V2
Canonical fields, in exact order:
`ios | min(screenW,screenH)xmax(screenW,screenH) | normalized DPR | timezone ID | primary language`

Hash:
- iterate UTF-16 code units
- `hash = hash * 31 + codeUnit` with signed Int32 overflow
- output `HW` + absolute magnitude in uppercase hexadecimal

Fixed self-test:
`ATTRIBUTION_TEST_VECTOR_V2 -> HWCB7C875`

## Network/IP
IP is intentionally NOT included in either HW/environment fingerprint. The current Worker already has a separate `network_fingerprint = hash(IP + UA)` fallback. For controlled H5→App network fallback testing, the app can send the exact H5 `navigator.userAgent` through the Worker's supported `user_agent` field.
