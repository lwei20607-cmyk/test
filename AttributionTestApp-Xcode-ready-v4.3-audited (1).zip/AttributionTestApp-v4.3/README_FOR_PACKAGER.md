# Attribution Fingerprint Lab v4.3 — packager instructions

Open `AttributionTestApp.xcodeproj` in Xcode, set your Signing Team and a valid Bundle Identifier, then build/archive for a real iPhone. Deployment target is iOS 15.0+.

Do NOT add TikTok SDK. Do NOT alter fingerprint source code. Do NOT hardcode any Cloudflare admin secret or TikTok access token into the app.

This IPA contains two clearly labeled algorithms:
- `LEGACY_H5_LAYOUT_NATIVE_APPROX_V1`
- `CROSS_SURFACE_V2`

The tester can paste the H5 result for each algorithm and the app will show MATCH/MISMATCH. It can also send either selected fingerprint to `/r/app/event` and run fingerprint-only tests.

## Network fallback requirement
The current Worker computes `network_fingerprint` from **IP + User-Agent**. Safari/H5 and a native app naturally have different User-Agent strings. Therefore, for a controlled H5→App network-fallback test, copy the H5 page's exact `navigator.userAgent` and paste it into the app's `H5 browser User-Agent` field before pressing a network-only test button. The app sends it as `user_agent`, which the current Worker explicitly accepts for `/r/app/event`.

Without the pasted H5 UA, a network-only event still sends, but it will normally NOT reproduce an H5 click's network fingerprint.

## Build acceptance
Before Archive/IPA, install a Debug build on one real iPhone and verify all three actions produce visible log changes and HTTP results:
1. `Check /health`
2. `Send View now`
3. `Test network fallback only`

Only Signing Team, Bundle Identifier, and signing/provisioning settings may be changed. The project is iPhone-device-only (`iphoneos`); use a real iPhone for the acceptance build.
