// EXACT reference of the user's currently deployed H5 fingerprint logic.
function getHWFingerprint() {
  var renderer = '';
  var vendor = '';
  try {
    var canvas = document.createElement('canvas');
    var gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
    if (gl) {
      var debugInfo = gl.getExtension('WEBGL_debug_renderer_info');
      if (debugInfo) {
        vendor = gl.getParameter(debugInfo.UNMASKED_VENDOR_WEBGL) || '';
        renderer = gl.getParameter(debugInfo.UNMASKED_RENDERER_WEBGL) || '';
      }
    }
  } catch (e) {}
  var parts = [
    renderer,
    vendor,
    navigator.hardwareConcurrency || '',
    screen.width + 'x' + screen.height,
    window.devicePixelRatio || 1,
    Intl.DateTimeFormat().resolvedOptions().timeZone || ''
  ];
  var str = parts.join('|');
  var hash = 0;
  for (var i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return 'HW' + Math.abs(hash).toString(16).toUpperCase();
}
