import Foundation
import UIKit
import Metal

struct FingerprintResult {
    let algorithmID: String
    let canonicalString: String
    let fingerprint: String
    let notes: String
}

/// Fingerprint lab used only for attribution fallback testing.
/// short_code remains primary. IP/network fingerprint remains a separate fallback in Worker.
struct FingerprintLab {
    static let hashTestVector = "ATTRIBUTION_TEST_VECTOR_V2"
    static let expectedHashTestResult = "HWCB7C875"

    /// Reproduces the existing H5 JavaScript 32-bit hash exactly for UTF-16 code units:
    /// hash = ((hash << 5) - hash) + charCode; hash |= 0;
    /// 'HW' + Math.abs(hash).toString(16).toUpperCase()
    static func js32Hash(_ input: String) -> String {
        var hash: Int32 = 0
        for codeUnit in input.utf16 {
            hash = hash &* 31 &+ Int32(codeUnit)
        }
        let magnitude: UInt32
        if hash == Int32.min {
            magnitude = 2_147_483_648
        } else if hash < 0 {
            magnitude = UInt32(-hash)
        } else {
            magnitude = UInt32(hash)
        }
        return "HW" + String(magnitude, radix: 16).uppercased()
    }

    static var hashSelfTestHash: String { js32Hash(hashTestVector) }
    static var hashSelfTestPassed: Bool { hashSelfTestHash == expectedHashTestResult }

    /// LEGACY-H5-LAYOUT approximation.
    /// Field ORDER and hash match the user's current H5 implementation exactly.
    /// Native values for WebGL renderer/vendor/hardwareConcurrency are only the closest native analogues,
    /// therefore equality with Safari is empirical and NOT guaranteed.
    static var legacyApprox: FingerprintResult {
        let renderer = MTLCreateSystemDefaultDevice()?.name ?? ""
        let vendor = "Apple"
        let cpu = ProcessInfo.processInfo.processorCount > 0 ? String(ProcessInfo.processInfo.processorCount) : ""
        let bounds = UIScreen.main.bounds
        let width = Int(bounds.width.rounded())
        let height = Int(bounds.height.rounded())
        let screen = "\(width)x\(height)"
        let dpr = normalizeDecimal(UIScreen.main.scale)
        let timezone = TimeZone.current.identifier
        let canonical = [renderer, vendor, cpu, screen, dpr, timezone].joined(separator: "|")
        return FingerprintResult(
            algorithmID: "LEGACY_H5_LAYOUT_NATIVE_APPROX_V1",
            canonicalString: canonical,
            fingerprint: js32Hash(canonical),
            notes: "Same field order/hash as current H5, but WebGL renderer/vendor and browser hardwareConcurrency are approximated with Metal/native values. Exact H5 equality is not guaranteed."
        )
    }

    /// Cross-surface v2 deliberately uses only fields that can be normalized on both H5 and native iOS.
    /// H5 must use the included H5_FINGERPRINT_V2.js for this result to be comparable.
    static var crossSurfaceV2: FingerprintResult {
        let bounds = UIScreen.main.bounds
        let a = Int(bounds.width.rounded())
        let b = Int(bounds.height.rounded())
        let shortSide = min(a, b)
        let longSide = max(a, b)
        let dpr = normalizeDecimal(UIScreen.main.scale)
        let timezone = TimeZone.current.identifier
        let language = primaryLanguage(Locale.preferredLanguages.first ?? "")
        let canonical = [
            "ios",
            "\(shortSide)x\(longSide)",
            dpr,
            timezone,
            language
        ].joined(separator: "|")
        return FingerprintResult(
            algorithmID: "CROSS_SURFACE_V2",
            canonicalString: canonical,
            fingerprint: js32Hash(canonical),
            notes: "Designed for H5/native comparison. Requires H5_FINGERPRINT_V2.js on the web side. Environment signature only; not a unique device ID."
        )
    }

    private static func normalizeDecimal(_ value: CGFloat) -> String {
        let d = Double(value)
        if abs(d.rounded() - d) < 0.000001 { return String(Int(d.rounded())) }
        var s = String(format: "%.2f", locale: Locale(identifier: "en_US_POSIX"), d)
        while s.contains(".") && s.last == "0" { s.removeLast() }
        if s.last == "." { s.removeLast() }
        return s
    }

    private static func primaryLanguage(_ raw: String) -> String {
        let lowered = raw.lowercased().replacingOccurrences(of: "_", with: "-")
        return lowered.split(separator: "-").first.map(String.init) ?? ""
    }
}

enum FingerprintAlgorithm: String, CaseIterable, Identifiable {
    case legacyApprox = "Legacy H5 layout (native approx)"
    case crossSurfaceV2 = "Cross-surface v2"
    var id: String { rawValue }
    var result: FingerprintResult {
        switch self {
        case .legacyApprox: return FingerprintLab.legacyApprox
        case .crossSurfaceV2: return FingerprintLab.crossSurfaceV2
        }
    }
}
