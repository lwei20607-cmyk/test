import Foundation
import UIKit

struct DeviceInfo {
    static var modelIdentifier: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }

    static var report: String {
        let device = UIDevice.current
        let v2 = FingerprintLab.crossSurfaceV2
        return [
            "device_model_identifier=\(modelIdentifier)",
            "system_name=\(device.systemName)",
            "system_version=\(device.systemVersion)",
            "cross_surface_fingerprint_version=\(v2.algorithmID)",
            "cross_surface_canonical=\(v2.canonicalString)",
            "cross_surface_hw_fingerprint=\(v2.fingerprint)",
            "cross_surface_self_test=\(FingerprintLab.hashSelfTestPassed ? "PASS" : "FAIL")"
        ].joined(separator: "\n")
    }
}
