import Foundation
import CryptoKit

struct WorkerEventPayload: Encodable {
    let event_type: String
    let event_id: String
    let event_time: Int
    let short_code: String?
    let hw_fingerprint: String?
    let amount: Double
    let currency: String
    let user_agent: String?
}

struct WorkerResult {
    let httpStatus: Int
    let body: String
    let eventID: String
    let sentPayload: String
}

enum AttributionMode: String, CaseIterable, Identifiable {
    case shortCodeAndFingerprint = "Short + Fingerprint"
    case fingerprintOnly = "Fingerprint only"
    case networkOnly = "Network only"

    var id: String { rawValue }
}

enum AttributionClientError: LocalizedError {
    case badURL
    case badHTTPResponse

    var errorDescription: String? {
        switch self {
        case .badURL: return "Invalid Worker URL"
        case .badHTTPResponse: return "Invalid HTTP response"
        }
    }
}

final class AttributionClient {
    static func sha256Hex(_ input: String) -> String {
        let digest = SHA256.hash(data: Data(input.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    static func health(baseURL: String) async throws -> WorkerResult {
        let normalized = baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: normalized + "/health") else { throw AttributionClientError.badURL }
        let (data, response) = try await URLSession.shared.data(from: url)
        guard let http = response as? HTTPURLResponse else { throw AttributionClientError.badHTTPResponse }
        return WorkerResult(
            httpStatus: http.statusCode,
            body: String(data: data, encoding: .utf8) ?? "<non-utf8 body>",
            eventID: "",
            sentPayload: ""
        )
    }

    static func sendEvent(
        baseURL: String,
        eventType: String,
        shortCode: String,
        fingerprint: String,
        mode: AttributionMode,
        amount: Double,
        currency: String,
        networkUserAgent: String
    ) async throws -> WorkerResult {
        let normalized = baseURL.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard let url = URL(string: normalized + "/r/app/event") else { throw AttributionClientError.badURL }

        let eventID = UUID().uuidString.lowercased()
        let trimmedShort = shortCode.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedFingerprint = fingerprint.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedNetworkUA = networkUserAgent.trimmingCharacters(in: .whitespacesAndNewlines)

        let payload = WorkerEventPayload(
            event_type: eventType.trimmingCharacters(in: .whitespacesAndNewlines),
            event_id: eventID,
            event_time: Int(Date().timeIntervalSince1970),
            short_code: mode == .shortCodeAndFingerprint && !trimmedShort.isEmpty ? trimmedShort : nil,
            hw_fingerprint: mode != .networkOnly && !trimmedFingerprint.isEmpty ? trimmedFingerprint : nil,
            amount: amount,
            currency: currency.uppercased(),
            user_agent: mode == .networkOnly && !trimmedNetworkUA.isEmpty ? trimmedNetworkUA : nil
        )

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try encoder.encode(payload)

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("AttributionTestApp/1.0 iOS", forHTTPHeaderField: "User-Agent")
        request.httpBody = data
        request.timeoutInterval = 20

        let (responseData, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw AttributionClientError.badHTTPResponse }

        return WorkerResult(
            httpStatus: http.statusCode,
            body: String(data: responseData, encoding: .utf8) ?? "<non-utf8 body>",
            eventID: eventID,
            sentPayload: String(data: data, encoding: .utf8) ?? "<payload encoding failed>"
        )
    }
}
