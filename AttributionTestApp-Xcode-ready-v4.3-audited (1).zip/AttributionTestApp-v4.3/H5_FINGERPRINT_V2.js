/*
 Cross-surface fingerprint v2 — H5 reference implementation.
 Must stay byte-for-byte logically aligned with CrossSurfaceFingerprint.swift.
 This is a FALLBACK environment signature, not a unique hardware identifier.
*/
(function (global) {
  'use strict';

  function primaryLanguage(raw) {
    return String(raw || '')
      .toLowerCase()
      .replace(/_/g, '-')
      .split('-')[0] || '';
  }

  function normalizeDecimal(value) {
    var n = Number(value);
    if (!Number.isFinite(n)) n = 1;
    if (Math.abs(Math.round(n) - n) < 0.000001) return String(Math.round(n));
    return n.toFixed(2).replace(/0+$/, '').replace(/\.$/, '');
  }

  function canonicalString() {
    var sw = Math.round(Number(screen.width) || 0);
    var sh = Math.round(Number(screen.height) || 0);
    var shortSide = Math.min(sw, sh);
    var longSide = Math.max(sw, sh);
    var dpr = normalizeDecimal(global.devicePixelRatio || 1);
    var timezone = '';
    try {
      timezone = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    } catch (_) {}
    var language = primaryLanguage(navigator.language || '');

    return [
      'ios',
      shortSide + 'x' + longSide,
      dpr,
      timezone,
      language
    ].join('|');
  }

  // JS signed-32-bit hash. Keep EXACTLY aligned with Swift implementation.
  function js32Hash(str) {
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash = hash | 0;
    }
    return 'HW' + Math.abs(hash).toString(16).toUpperCase();
  }

  var TEST_VECTOR = 'ATTRIBUTION_TEST_VECTOR_V2';
  var EXPECTED_TEST_HASH = 'HWCB7C875';

  global.AttributionFingerprintV2 = {
    version: 'v2',
    canonicalString: canonicalString,
    fingerprint: function () { return js32Hash(canonicalString()); },
    hash: js32Hash,
    selfTestHash: function () { return js32Hash(TEST_VECTOR); },
    selfTestPassed: function () { return js32Hash(TEST_VECTOR) === EXPECTED_TEST_HASH; }
  };
})(window);
